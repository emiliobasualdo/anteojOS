#include <buddySystem.h>

/**
 * para manejar memoria nos basamos en el buddy system
 * O(log(n)), n = memoria total que maneja el buddy
 * link de youtube que explica como funciona: --> https://www.youtube.com/watch?v=1pCC6pPAtio
 */
buddySystem startBuddySystem (uint64_t totalMemory, freeFn free, allocFn alloc, uint64_t offset)
{
    // TODO testear los parametros
    buddySystem newBSystem = alloc(sizeof(buddySystemCDT));
    // TODO chequear que se haya alocado bien

    newBSystem->offset=offset;
    newBSystem->alloc=alloc;
    newBSystem->free=free;

    /** calculo la cantidad que voy a manejar con potencias de 2
     * ejemplo: si me dicen de manejar 511 bytes, voy a manejar 256 bytes */
    newBSystem->memSize=getSize(totalMemory);

    memorySlot totalMemorySlot = createMemSlot(newBSystem->memSize, 0, alloc);
    newBSystem->root = createBTree(totalMemorySlot, alloc);

    return newBSystem;
}

/** source: https://stackoverflow.com/questions/2679815/previous-power-of-2
 * retorna la potencia de 2 mas cercana y menor o igual
 * ejemplo: 511 retorna 256 */
uint64_t getSize(uint64_t totalMemory)
{
    uint64_t x = totalMemory;
    x = x | (x >> 1);
    x = x | (x >> 2);
    x = x | (x >> 4);
    x = x | (x >> 8);
    x = x | (x >> 16);
    return x - (x >> 1);
}

/** crea una instancia de la estructura del memory slot para que sea la data del nodo del arbol */
memorySlot createMemSlot(uint64_t slotSize, uint64_t memSize, allocFn alloc)
{
    memorySlot newMemSlot = alloc(sizeof(memorySlotCDT)); // TODO chequear alloc
    newMemSlot->slotSize=slotSize;
    newMemSlot->memSize=memSize;
    newMemSlot->state=FREE;
    return newMemSlot;
}

/** funcion recursiva para alocar memoria
 * retorna la direccion de memoria donde se aloco
 * o NULL si no habia lugar */
uint64_t allocateMemory(binaryTree bTree, uint64_t sizeToAdd, allocFn alloc, uint64_t currOffset)
{
    // TODO chequear parametros (sizeToAdd tiene que ser menor a totalMemory, etc)

    memorySlot currMemorySlot = bTree->data;

    if (currMemorySlot->state == SPLIT)
    {
        uint64_t ret = allocateMemory(bTree->right, sizeToAdd, alloc, currOffset);
        if (ret == NULL)
        {
            return allocateMemory(bTree->left, sizeToAdd, alloc, currOffset+currMemorySlot->memSize);
        }
        else
        {
            return ret;
        }
    }
    if (currMemorySlot->state == FREE)
    {
        if (currMemorySlot->slotSize/2 < sizeToAdd)
        {
            currMemorySlot->memSize = sizeToAdd;
            currMemorySlot->state=OCCUPIED;
            return currOffset;
        }
        else
        {
            splitTree(bTree, alloc);
            return allocateMemory(bTree, sizeToAdd, alloc, currOffset);
        }
    }
    if (currMemorySlot->state == OCCUPIED)
    {
        return NULL;
    }
}

void splitTree(binaryTree bTree, allocFn alloc)
{
    memorySlot currMemSlot = bTree->data;

    memorySlot memSlotLeft = createMemSlot(currMemSlot->slotSize / 2, 0, alloc);
    binaryTree bTreeLeft = createBTree(memSlotLeft, alloc);

    memorySlot memSlotRight = createMemSlot(currMemSlot->slotSize / 2, 0, alloc);
    binaryTree bTreeRight = createBTree(memSlotRight, alloc);

    bTree->left = bTreeLeft;
    bTree->right = bTreeRight;
}

int8_t freeMemory(binaryTree bTree, uint64_t currOffset, uint64_t memToFreeOffset, freeFn free)
{
    // TODO  chequear parametros

    memorySlot currMemSlot = bTree->data;

    if (currOffset == memToFreeOffset && currMemSlot->state == OCCUPIED)
    {
        currMemSlot->state=FREE;
        return 1;
    }
    if (currMemSlot->state == SPLIT)
    {
        int8_t freed;

        if (currOffset < currMemSlot->memSize / 2)
        {
             freed = freeMemory(bTree->right, currOffset, memToFreeOffset, free);
        }
        else
        {
             freed = freeMemory(bTree->left, currOffset + currMemSlot->memSize, memToFreeOffset, free);
        }
        if (freed)
        {
            mergeChildren(bTree, free);
            return 0;
        }
        return freed;
    }
    if (currMemSlot->state == FREE)
    {
        return -1;          /** porque no deberiamos llegar al caso de una hoja libre, retornamos -1 */
    }
    if (currMemSlot->state == OCCUPIED)
    {
        return -1;          /** porque no deberiamos llegar al caso de una hoja ocupada que no es la que queriamos liberar, retornamos -1 */
    }
}

void mergeChildren (binaryTree bTree, freeFn free)
{
    memorySlot memSlotLeft = bTree->left->data;
    memorySlot memSlotRight = bTree->right->data;
    memorySlot memSlot = bTree->data;

    if (memSlotLeft->state == FREE && memSlotRight->state == FREE)
    {
        memSlot->state=FREE;
        freeBTree(bTree->left, free);       /** este free libera el memSlot tambien */
        freeBTree(bTree->right, free);
        bTree->left=NULL;
        bTree->right=NULL;
    }
}

void endBuddySystem(buddySystem buddy)
{
    if (buddy != NULL)
    {
        endBuddySystemRec(buddy->root, buddy->free);
        buddy->free(buddy);
    }
}

void endBuddySystemRec (binaryTree bTree, freeFn free)
{
    if (bTree->left == NULL && bTree->right == NULL)
    {
        free(bTree);
        return;
    }

    endBuddySystemRec(bTree->left, free);
    endBuddySystemRec(bTree->right, free);
}

uint64_t calculateInternalFragmentation(buddySystem buddy)
{
    return calculateInternalFragmentationRec(buddy->root);
}

uint64_t calculateInternalFragmentationRec(binaryTree bTree)
{
    memorySlot currMemSlot = bTree->data;
    if (bTree->right== NULL && bTree->left==NULL)
    {
        return currMemSlot->slotSize - currMemSlot->memSize;
    }

    return calculateInternalFragmentationRec(bTree->left) + calculateInternalFragmentationRec(bTree->right);
}