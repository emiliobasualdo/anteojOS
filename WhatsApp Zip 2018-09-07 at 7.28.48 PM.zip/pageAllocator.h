#ifndef PAGEALLOCATOR_H
#define PAGEALLOCATOR_H

#include <stdint.h>
#include <buddySystem.h>
#include <memoryManager.h>
#include <linearList.h>

#define PAGE_SIZE 4096                  /** --> = 4 KiB */
#define SCM_DATA_OFFSET 0x600000        // TODO no encuentro esto
#define MAX_BLOCKS 524287            // TODO chequear esto

uint64_t getNumOfNodes(uint64_t totalSize);
uint64_t max (uint64_t num1, uint64_t num2);
uint64_t getSizeForMemManager(uint64_t totalSize);
uint64_t setAllocSize ();
void setAllocatorForMemManager();
void * allocForMemManager(long size);
void freeForMemManager(void * offset);
uint64_t getSizeForBlocksArray(uint64_t sizeForMemManager);
void pageFree(void * address);
void * pageAlloc(long size);
void initializePageAllocator();
void endPageAllocator();

#endif