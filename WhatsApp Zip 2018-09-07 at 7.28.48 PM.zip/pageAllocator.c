#include <stddef.h>
#include "pageAllocator.h"

extern uint32_t endOfKernel;

static uint64_t offset;
static long allocSize;
static uint64_t totalBlocks;
uint8_t blocks[MAX_BLOCKS];
uint64_t sizeForMemManager;
memoryManager memManager;

/** calcula la cantidad de memoria total en anteojOS
 * calcula la cantidad de memoria que va a utilizar el memory manager y el array de bloques
 * calcula los offsets, para el page allocator y para el memory manager
 * inicializa el memory manager y el array de bloques
 *
 * el array de bloques se utiliza para el alloc y el free del memory manager
 * cada elemento representa el bloque en memoria que se aloca cuando se llama al allocForMemManager
 * si el bloque esta en 0, es porque esta libre
 * si esta en 1, es porque esta ocupado
 * luego si se quiere alocar en el bloque #7, la direccion es offset + 7 * allocSize
 */
void initializePageAllocator()
{
    offset = max(endOfKernel, SCM_DATA_OFFSET);
    uint64_t totalSize = 1024 * 1024 * 1024;            /** ---> 1 GB es la imagen total */
    uint64_t totalSizeLeft = totalSize - offset;
    sizeForMemManager = getSizeForMemManager(totalSizeLeft);
    uint64_t sizeForBlocksArray = getSizeForBlocksArray(sizeForMemManager);
    uint64_t offsetForMemManager = offset + sizeForMemManager + sizeForBlocksArray;
    memManager = startMemoryManager(offsetForMemManager, totalSizeLeft-sizeForMemManager-sizeForBlocksArray, allocForMemManager, freeForMemManager);

    setAllocatorForMemManager();
}

void * pageAlloc(long size)
{
    return ((void *) requestPages(memManager,(uint64_t) size, allocForMemManager));
}

void pageFree(void * address)
{
    freePages(memManager, (uint64_t ) address);
}

/** calcula el tamaño en memoria necesario para reservar el array de bloques */
uint64_t getSizeForBlocksArray(uint64_t sizeForMemManager)
{
    allocSize = (long) setAllocSize();
    totalBlocks = sizeForMemManager / allocSize;
    return totalBlocks*sizeof(uint8_t) + sizeof(uint8_t *);
}

/** setea cada bloque en 0, indicando que el espacio esta libre */
void setAllocatorForMemManager()
{
    for (int i=0; i<totalBlocks; i++)
    {
        blocks[i] = 0;
    }
}

/** calcula el tamaño en memoria necesario para reservar el memory manager */
uint64_t getSizeForMemManager(uint64_t totalSize)
{
    uint64_t buddySystemSize = sizeof(buddySystemCDT) + sizeof(buddySystem);
    uint64_t memManagerSize = sizeof(memoryManagerCDT) + sizeof(memoryManager);
    uint64_t treeNodeSize = sizeof(memorySlotCDT) + sizeof(memorySlot);

    uint64_t sizeNeeded = getNumOfNodes(totalSize) * treeNodeSize;
    sizeNeeded += buddySystemSize*N_BUDDIES;
    sizeNeeded += memManagerSize;
    return sizeNeeded;
}

uint64_t max (uint64_t num1, uint64_t num2)
{
    return (num1 >= num2) ? num1 : num2;
}

/** calcula la cantidad de nodos que tendria el buddy system si maneja el tamaño @totalSize */
uint64_t getNumOfNodes(uint64_t totalSize)
{
    uint64_t qtyPages = totalSize/PAGE_SIZE;
    qtyPages = getSize(qtyPages);               /** hacemos que sea potencia de 2 con el metodo del buddy system*/
    // TODO pasar este metodo a una libreria de math junto con max
    uint64_t qtyNodes = qtyPages;

    while (qtyPages > 0)
    {
        qtyPages /= 2;
        qtyNodes += qtyPages;
    }

    return qtyNodes;
}

/** para poder hacer un free en el espacio en memoria designado al memory manager
 * necesito que los bloques que aloco sean constantes
 * por lo cual no voy a usar la variable size que me pasan como parametro
 * y uso allocSize */
void * allocForMemManager(long size)
{
    void * addressAux = (void *) offset;
    for (int i=0; i<totalBlocks; i++)
    {
        if (!blocks[i])
        {
            blocks[i] = 1;
            return addressAux;
        }
        addressAux += allocSize;
    }
    return NULL;
}

/** encuentra el bloque que maneja la direccion @offsetBlock y setea el 0 */
void freeForMemManager(void * offsetBlock)
{
    uint64_t index = ((uint64_t ) (offsetBlock - offset)) / allocSize;
    blocks[index] = 0;
}

/** retorna el tamaño maximo entre las estructuras que maneja el memory manager */
uint64_t setAllocSize ()
{
    uint64_t buddySystemSize = sizeof(buddySystemCDT);
    uint64_t memManagerSize = sizeof(memoryManagerCDT);
    uint64_t treeNodeSize = sizeof(memorySlotCDT);

    if ( buddySystemSize >= memManagerSize)
    {
        return max (buddySystemSize, treeNodeSize);
    }
    else
    {
        return max (memManagerSize, treeNodeSize);
    }
}

void endPageAllocator()
{
    endMemoryManager(memManager);
}
