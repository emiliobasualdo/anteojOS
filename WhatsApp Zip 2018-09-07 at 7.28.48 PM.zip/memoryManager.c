#include "memoryManager.h"

/** el memory manager va a usar muchos buddies para manegar la memoria */

memoryManager startMemoryManager(uint64_t offset, uint64_t totalMemory, allocFn alloc, freeFn free)
{
    // TODO chequear parametros
    memoryManager newMemManager = alloc(sizeof(memoryManagerCDT));
    newMemManager->numBuddies = startBuddies(newMemManager, offset, totalMemory, alloc, free);
    newMemManager->free=free;
    newMemManager->alloc=alloc;
    return newMemManager;
}

uint64_t startBuddies(memoryManager memManager, uint64_t offset, uint64_t totalMemory, allocFn alloc, freeFn free)
{
    memManager->buddies = alloc((long) N_BUDDIES* sizeof(buddySystem));
    uint64_t remainingSize = totalMemory;
    uint64_t numOfBuddies = 0;

    for (int i=0; i<N_BUDDIES && remainingSize>0; i++)
    {
        memManager->buddies[i] = startBuddySystem(remainingSize, free, alloc, offset);
        remainingSize -= getSize(remainingSize);
        offset += (totalMemory-remainingSize);
        numOfBuddies++;
    }

    return numOfBuddies;
}

/** funcion que retorna las direcciones a las paginas donde se aloca la memoria de tamaño memSize */
uint64_t requestPages(memoryManager memManager, uint64_t memSize, allocFn alloc)
{
    // TODO chequear parametros

    buddySystem buddy = chooseBestBuddy(memManager->buddies, memManager->numBuddies, memSize);
    if (buddy == NULL)
    {
        return NULL;
    }
    return allocateMemory(buddy->root, memSize, alloc, buddy->offset);
}

/** funcion que recibe el offset del espacio de memoria que se quiere liberar
 * elige el buddy que maneja esa direccion de memoria chequeando que @address se encuentre
 * entre el offset del buddy y el memSize del buddy
 */
void freePages(memoryManager memManager, uint64_t address)
{
    int found = 0;
    for (int i=0; i<memManager->numBuddies && !found; i++)
    {
        uint64_t index = address - memManager->buddies[i]->offset;
        if (index < memManager->buddies[i]->memSize)
        {
            freeMemory(memManager->buddies[i]->root, memManager->buddies[i]->offset, address, memManager->free);
            found = 1;
        }
    }
}

/** elige el mejor buddy para manejar la memoria requerida */
buddySystem chooseBestBuddy(buddySystem * buddies, uint64_t numBuddies, uint64_t memSize)
{
    uint64_t buddySize;
    for (int i= (int) (numBuddies - 1); i >= 0; i++)
    {
        buddySize = buddies[i]->memSize;
        if (buddySize > memSize)
        {
            return buddies[i];
        }
    }
    return NULL;
}

void endMemoryManager(memoryManager memManager)
{
    for (int i=0; i<N_BUDDIES; i++)
    {
        memManager->free(memManager->buddies[i]);
    }
    memManager->free(memManager);
}

